function totalNecessidadesEnergia() {
    var idDistrito = new Number($('#distrito').val());
    var inputValue = new Number($('#tipo-consumo-value' + rowId).val());
    var idTipo = new Number($('#tipo-consumo' + rowId).val());
    var idPerfilMensal = new Number($('#perfil-mensal').val());
    var idPerfilSemanal = new Number($('#perfil-semanal').val());
    
    var totalInputs = (inputValue * consumo_diario_agua[idTipo].valor);
    var totalPerfil = 0;

    //TOTAL MESES
    var totalJan = 0;
    var totalFev = 0;
    var totalMar = 0;
    var totalAbr = 0;
    var totalMai = 0;
    var totalJun = 0;
    var totalJul = 0;
    var totalAgo = 0;
    var totalSet = 0;
    var totalOut = 0;
    var totalNov = 0;
    var totalDez = 0;

    var total = 0;

    //Tabela perfil semanal vars
    var segunda = $('#perfil-semanal-input1').val();
    var terca = $('#perfil-semanal-input2').val();
    var quarta = $('#perfil-semanal-input3').val();
    var quinta = $('#perfil-semanal-input4').val();
    var sexta = $('#perfil-semanal-input5').val();
    var sabado = $('#perfil-semanal-input6').val();
    var domingo = $('#perfil-semanal-input7').val();


    for(var i = 0; i < perfil_mensal[idPerfilMensal].tabela.length; i++) {
        totalPerfilMensal = perfil_mensal[idPerfilMensal].tabela[i].valor;
    }


    if (idPerfilSemanal == 0 || idPerfilSemanal == 1) {
        totalPerfilSemanal = totalInputs * totalPerfilMensal * perfil_semanal[idPerfilSemanal].valor;
    } else if (idPerfilSemanal == 3) {
        totalPerfilSemanal = totalInputs * totalPerfilMensal * ((segunda + terca + quarta + quinta + sexta + sabado + domingo) / 7);
    }

    totalJan = (totalPerfilSemanal * meses_numero_horas[0].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[0].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalFev = (totalPerfilSemanal * meses_numero_horas[1].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[1].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalMar = (totalPerfilSemanal * meses_numero_horas[2].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[2].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalAbr = (totalPerfilSemanal * meses_numero_horas[3].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[3].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalMai = (totalPerfilSemanal * meses_numero_horas[4].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[4].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalJun = (totalPerfilSemanal * meses_numero_horas[5].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[5].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalJul = (totalPerfilSemanal * meses_numero_horas[6].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[6].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalAgo = (totalPerfilSemanal * meses_numero_horas[7].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[7].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalSet = (totalPerfilSemanal * meses_numero_horas[8].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[8].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalOut = (totalPerfilSemanal * meses_numero_horas[9].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[9].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalNov = (totalPerfilSemanal * meses_numero_horas[10].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[10].valorTempAgua) * fatores_conversao[0]).toFixed(0);
    totalDez = (totalPerfilSemanal * meses_numero_horas[11].n_dias * (temperatura_utilizacao_alto - irradiacao_temp_amb_temp_agua[idDistrito].mesI[11].valorTempAgua) * fatores_conversao[0]).toFixed(0);


    total = totalJan + totalFev + totalMar + totalAbr + totalMai + totalJun + totalJul + totalAgo + totalSet + totalOut + totalNov + totalDez;

}